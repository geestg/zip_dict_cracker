"""
zip_dict_cracker.py

Deskripsi:
  Program ini mencoba membuka file ZIP terenkripsi dengan
  membaca kandidat password dari file wordlist (satu kata per baris).
  Hasil percobaan dicatat ke file CSV log. Hanya untuk penggunaan
  etis (file milik Anda atau dengan izin).

Cara pakai:
  python zip_dict_cracker.py path_ke_file.zip path_ke_wordlist.txt

Contoh:
  python zip_dict_cracker.py secret.zip wordlist.txt

Catatan teknis:
  - zipfile.setpassword() menerima bytes; program mencoba
    encoding 'utf-8' dan 'cp437' (sering dipakai pada ZIP).
  - Jika ZIP memiliki banyak file, program akan mencoba membuka
    file pertama dalam arsip untuk menguji password.
  - Program tidak melakukan brute-force kombinatorial besar — hanya
    mencoba kata-kata dari wordlist yang Anda sediakan.
"""

import sys
import zipfile
import time
import csv
from datetime import datetime

def try_password(zf: zipfile.ZipFile, pwd_str: str) -> bool:
    """
    Coba password pada zipfile.ZipFile zf.
    Mengembalikan True jika berhasil mengekstrak file uji tanpa Exception.
    """
    # zipfile expects password as bytes
    # coba dua encoding umum: utf-8 dan cp437
    encodings = ['utf-8', 'cp437']
    for enc in encodings:
        try:
            pwd = pwd_str.encode(enc, errors='strict')
        except Exception:
            # skip encoding yang gagal
            continue

        try:
            # pilih nama file uji: file pertama di daftar
            test_name = zf.namelist()[0]
        except IndexError:
            return False  # arsip kosong

        try:
            # open() akan melempar RuntimeError atau BadZipFile atau RuntimeError jika password salah
            with zf.open(test_name, pwd) as f:
                # baca sedikit data untuk memastikan dekripsi berhasil
                _ = f.read(16)
            return True
        except RuntimeError:
            # password salah atau metode enkripsi tidak didukung
            continue
        except zipfile.BadZipFile:
            # tidak dapat membuka file (bukan zip yang valid)
            return False
        except Exception:
            # tangani exception lain secara aman -> lanjutkan mencoba encoding lain
            continue
    return False

def run_cracker(zip_path: str, wordlist_path: str, log_csv: str = "zip_crack_log.csv"):
    start_time = time.time()
    attempts = 0
    found = False
    found_pwd = None

    try:
        zf = zipfile.ZipFile(zip_path, 'r')
    except FileNotFoundError:
        print(f"[ERROR] File ZIP tidak ditemukan: {zip_path}")
        return
    except zipfile.BadZipFile:
        print(f"[ERROR] File bukan ZIP valid: {zip_path}")
        return

    # siapkan file log CSV
    with open(log_csv, mode='w', newline='', encoding='utf-8') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(['timestamp', 'attempt_no', 'password_candidate', 'result', 'elapsed_seconds'])

        try:
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as wl:
                for line in wl:
                    candidate = line.rstrip('\n\r')
                    if not candidate:
                        continue  # skip baris kosong

                    attempts += 1
                    t0 = time.time()
                    ok = try_password(zf, candidate)
                    elapsed = time.time() - t0

                    result = "success" if ok else "fail"
                    timestamp = datetime.utcnow().isoformat() + 'Z'

                    csvwriter.writerow([timestamp, attempts, candidate, result, f"{elapsed:.4f}"])
                    # flush setiap baris agar log tetap tersimpan jika terhenti
                    csvfile.flush()

                    # tampilkan progres sederhana
                    if attempts % 50 == 0:
                        print(f"[PROGRESS] {attempts} percobaan ... terakhir: '{candidate}' -> {result}")

                    if ok:
                        found = True
                        found_pwd = candidate
                        print(f"[FOUND] Password berhasil: '{candidate}' (percobaan ke-{attempts})")
                        break
        except FileNotFoundError:
            print(f"[ERROR] Wordlist tidak ditemukan: {wordlist_path}")
            return
        except Exception as e:
            print(f"[ERROR] Terjadi kesalahan saat membaca wordlist: {e}")
            return

    total_time = time.time() - start_time
    print("===========================================")
    print(f"Total percobaan : {attempts}")
    print(f"Waktu eksekusi   : {total_time:.2f} detik")
    if found:
        print(f"Hasil            : Password ditemukan -> '{found_pwd}'")
    else:
        print("Hasil            : Password tidak ditemukan dalam wordlist.")
    print(f"Log disimpan di  : {log_csv}")
    print("===========================================")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python zip_dict_cracker.py path_ke_file.zip path_ke_wordlist.txt")
        sys.exit(1)

    zip_path = sys.argv[1]
    wordlist_path = sys.argv[2]
    run_cracker(zip_path, wordlist_path)
